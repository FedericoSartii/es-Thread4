public class Start {
    public static void main(String[] args) throws Exception {
        Risorsa r = new Risorsa();
        Produttore p1 = new Produttore("Prod1", r);
        Produttore p2 = new Produttore("Prod2", r);
        Consumatore c1 = new Consumatore("Cons1", r);
        Consumatore c2 = new Consumatore("Cons2", r);

        p1.start();
        p2.start();
        c1.start();
        c2.start();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
        }
        c1.arresta();
        c2.arresta();
        p1.arresta();
        p2.arresta();

        System.out.println("THread MAIN FINE");
    }
}